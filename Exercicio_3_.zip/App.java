package Exercicio3;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        int escolha = 0;

        Restaurante r = new Restaurante();
        Mesa m = new Mesa();
        Conta c = new Conta();

        r.adicionarPrato("Feijoada", 30);
        r.adicionarPrato("Frango Assado", 35);
        r.adicionarPrato("Carne de Panela", 20);

        m.setGarcom("Fernando");
        m.setConta(c);
        m.setAberta(true);

        r.adicionarMesa(m);

        c.adicionarPedido("Feijoada", 30, 1);
        c.adicionarPedido("Frango Assado", 35, 1);
        c.adicionarPedido("Carne de Panela", 20, 1);
        do {
            System.out.println(
                    "1 - Buscar prato;\n2 - Verificar disponibilidade de mesa;\n3 - Solicitar conta;\n4 - Sair.");
            escolha = entrada.nextInt();

            switch (escolha) {
                case 1:
                r.pesquisarPrato("Prato 1");
                    break;
                case 2:
                r.mesaIsDisponivel(m);
                    
                    break;
                case 3:
                r.solicitarConta(m);
                    break;
            }
            
        } while (escolha != 4);
        if(escolha==4){
            System.out.println("\nObrigada pela Preferência!");
        }
        entrada.close();
    }
}